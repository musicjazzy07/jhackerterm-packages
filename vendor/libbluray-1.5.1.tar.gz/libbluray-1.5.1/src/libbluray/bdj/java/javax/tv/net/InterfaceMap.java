/*
 * This file is part of libbluray
 * Copyright (C) 2016  VideoLAN
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see
 * <http://www.gnu.org/licenses/>.
 */

package javax.tv.net;

import java.io.IOException;
import java.net.InetAddress;
import javax.tv.locator.InvalidLocatorException;
import javax.tv.locator.Locator;

public class InterfaceMap
{
    public static InetAddress getLocalAddress(Locator locator)
        throws InvalidLocatorException, IOException {

        org.videolan.Logger.unimplemented(InterfaceMap.class.getName(), "getLocalAddress");
        throw new InvalidLocatorException(locator, "Unsupported");
    }
}
