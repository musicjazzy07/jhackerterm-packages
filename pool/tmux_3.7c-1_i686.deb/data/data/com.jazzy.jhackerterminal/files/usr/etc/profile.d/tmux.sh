export TMUX_TMPDIR=/data/data/com.jazzy.jhackerterminal/files/usr/var/run
