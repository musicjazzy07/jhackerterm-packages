/*
  Copyright @ 1999 ImageMagick Studio LLC, a non-profit organization
  dedicated to making software imaging solutions freely available.

  You may not use this file except in compliance with the License.  You may
  obtain a copy of the License at

    https://imagemagick.org/license/

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

  MagickCore methods to lock and unlock semaphores.
*/
#ifndef MAGICKCORE_SEMAPHORE_H
#define MAGICKCORE_SEMAPHORE_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

typedef struct SemaphoreInfo
  SemaphoreInfo;

extern MagickExport SemaphoreInfo
  *AcquireSemaphoreInfo(void);

extern MagickExport void
  ActivateSemaphoreInfo(SemaphoreInfo **),
  LockSemaphoreInfo(SemaphoreInfo *),
  RelinquishSemaphoreInfo(SemaphoreInfo **),
  UnlockSemaphoreInfo(SemaphoreInfo *);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif
